import Navbar from "../components/Navbar.jsx";
import Productos from "../components/Productos"


const profile = () => {
    return (
        <div>
            <Navbar></Navbar>
            <Productos></Productos>
        </div>
    )
}
export default profile;