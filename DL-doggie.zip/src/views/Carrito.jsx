import Carro from "../components/Carro.jsx";

export default function Carrito() {

    return(
        <Carro></Carro>
    )
}