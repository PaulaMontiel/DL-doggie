import Navbar from "../components/Navbar.jsx";
import Profile from "../components/UserProfile"


const profile = () => {
    return (
        <div>
            <Navbar></Navbar>
            <Profile></Profile>
        </div>
    )
}
export default profile;