import Navbar from "../components/Navbar.jsx";
import Login from "../components/login.jsx";


const MyLogin = () => {
    return (
        <div>
            <Navbar></Navbar>
            <Login></Login>
        </div>
    )
}
export default MyLogin;