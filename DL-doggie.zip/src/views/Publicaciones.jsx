import Navbar from "../components/Navbar.jsx";
import PublicacionesDet from "../components/PublicacionesDet.jsx";

export default function Publicaciones() {
    
    return (
        <>
            <Navbar></Navbar>
            <PublicacionesDet></PublicacionesDet>
        </>
    );
}